SELECT * FROM Contacts;
