﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactManager
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnAddContact_Click(object sender, EventArgs e)
        {
            // Open Add Contact Form
            AddContactForm addContactForm = new AddContactForm();
            addContactForm.ShowDialog();
        }


        private void btnViewContacts_Click(object sender, EventArgs e)
        {
            // Open View Contacts Form
            ViewContactsForm viewContactsForm = new ViewContactsForm();
            viewContactsForm.ShowDialog();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
