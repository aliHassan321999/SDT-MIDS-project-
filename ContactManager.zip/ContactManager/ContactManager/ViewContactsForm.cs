﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;  // Required for file path handling

namespace ContactManager
{
    public partial class ViewContactsForm : Form
    {
        private readonly string dbConn;

        public ViewContactsForm()
        {
            InitializeComponent();

            // Fetch database connection details from App.config
            dbConn = ConfigurationManager.ConnectionStrings["DatabaseConn"].ConnectionString;

            if (string.IsNullOrEmpty(dbConn))
            {
                MessageBox.Show("Error: Database connection details are missing!", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Load all contacts when the form opens
            LoadAllContacts();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            SearchContacts(txtSearch.Text.Trim());
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchContacts(txtSearch.Text.Trim());
        }
        private void SearchContacts(string searchValue)
        {
            if (string.IsNullOrEmpty(searchValue)) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(dbConn))
                {
                    conn.Open();
                    string query = "SELECT ID, Name, Phone, Email FROM Contacts WHERE Name LIKE @searchValue OR Phone LIKE @searchValue OR Email LIKE @searchValue";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@searchValue", "%" + searchValue + "%");

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            dataGridViewContacts.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching contacts: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLoadContacts_Click(object sender, EventArgs e)
        {
            LoadAllContacts();
        }
        private void ExportToExcel()
{
    try
    {
        // Create Excel Application
        Excel.Application excelApp = new Excel.Application();
        if (excelApp == null)
        {
            MessageBox.Show("Excel is not installed on this system!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // Create a new workbook and worksheet
        Excel.Workbook workbook = excelApp.Workbooks.Add();
        Excel.Worksheet worksheet = workbook.ActiveSheet;
        worksheet.Name = "Contacts";

        int excelColumnIndex = 1; // Track actual column index in Excel

        // Add column headers with bold formatting, excluding Edit/Delete
        for (int i = 0; i < dataGridViewContacts.Columns.Count; i++)
        {
            string columnName = dataGridViewContacts.Columns[i].HeaderText;

            // Exclude Edit and Delete columns
            if (columnName != "Edit" && columnName != "Delete" && dataGridViewContacts.Columns[i].Visible)
            {
                Excel.Range headerCell = worksheet.Cells[1, excelColumnIndex];
                headerCell.Value = columnName;
                headerCell.Font.Bold = true;
                excelColumnIndex++;
            }
        }

        // Reset column index for data rows
        int rowIndex = 2;

        // Add data rows, excluding Edit/Delete
        for (int i = 0; i < dataGridViewContacts.Rows.Count; i++)
        {
            excelColumnIndex = 1; // Reset for each row

            for (int j = 0; j < dataGridViewContacts.Columns.Count; j++)
            {
                string columnName = dataGridViewContacts.Columns[j].HeaderText;

                // Exclude Edit and Delete columns
                if (columnName != "Edit" && columnName != "Delete" && dataGridViewContacts.Columns[j].Visible)
                {
                    object cellValue = dataGridViewContacts.Rows[i].Cells[j].Value;
                    string cleanValue = cellValue != null ? cellValue.ToString().Replace("$", "") : ""; // Remove dollar signs

                    worksheet.Cells[rowIndex, excelColumnIndex] = cleanValue;
                    excelColumnIndex++;
                }
            }
            rowIndex++;
        }

        // AutoFit columns
        worksheet.Columns.AutoFit();

        // Set file save path to Desktop
        string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string savePath = Path.Combine(desktopPath, "Contacts.xlsx");

        // Save and close
        workbook.SaveAs(savePath);
        workbook.Close();
        excelApp.Quit();

        MessageBox.Show("Exported successfully!\nFile saved at: {savePath}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error exporting to Excel: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}



        private void LoadAllContacts()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(dbConn))
                {
                    conn.Open();
                    string query = "SELECT ID, Name, Phone, Email FROM Contacts";  // Added Email

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            dataGridViewContacts.DataSource = dt;

                            // Make sure ID is always ReadOnly
                            if (dataGridViewContacts.Columns["ID"] != null)
                            {
                                dataGridViewContacts.Columns["ID"].ReadOnly = true;
                            }

                            // Prevent duplicate buttons
                            if (dataGridViewContacts.Columns["Edit"] == null)
                            {
                                DataGridViewButtonColumn editColumn = new DataGridViewButtonColumn
                                {
                                    Name = "Edit",
                                    Text = "Edit",
                                    UseColumnTextForButtonValue = true
                                };
                                dataGridViewContacts.Columns.Add(editColumn);
                            }

                            if (dataGridViewContacts.Columns["Delete"] == null)
                            {
                                DataGridViewButtonColumn deleteColumn = new DataGridViewButtonColumn
                                {
                                    Name = "Delete",
                                    Text = "Delete",
                                    UseColumnTextForButtonValue = true
                                };
                                dataGridViewContacts.Columns.Add(deleteColumn);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading contacts: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void dataGridViewContacts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; // Ignore header row

            int contactID = Convert.ToInt32(dataGridViewContacts.Rows[e.RowIndex].Cells["ID"].Value);

            if (dataGridViewContacts.Columns[e.ColumnIndex].Name == "Edit")
            {
                EditContact(contactID, e.RowIndex);
            }
            else if (dataGridViewContacts.Columns[e.ColumnIndex].Name == "Delete")
            {
                DeleteContact(contactID);
            }
        }

        private void EditContact(int contactID, int rowIndex)
        {
            // Get current values
            string oldName = dataGridViewContacts.Rows[rowIndex].Cells["Name"].Value.ToString();
            string oldPhone = dataGridViewContacts.Rows[rowIndex].Cells["Phone"].Value.ToString();

            // Prompt user for new values
            string newName = Microsoft.VisualBasic.Interaction.InputBox("Enter new name:", "Edit Contact", oldName);
            string newPhone = Microsoft.VisualBasic.Interaction.InputBox("Enter new phone number:", "Edit Contact", oldPhone);

            // Validate inputs
            if (string.IsNullOrWhiteSpace(newName) || string.IsNullOrWhiteSpace(newPhone))
            {
                MessageBox.Show("Name and Phone cannot be empty!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if changes were actually made
            if (newName == oldName && newPhone == oldPhone)
            {
                MessageBox.Show("No changes were made.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Confirm update
            DialogResult confirmEdit = MessageBox.Show("Are you sure you want to update this contact?",
                "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmEdit == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(dbConn))
                    {
                        conn.Open();
                        string query = "UPDATE Contacts SET Name = @Name, Phone = @Phone WHERE ID = @ID";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@ID", contactID);
                            cmd.Parameters.AddWithValue("@Name", newName);
                            cmd.Parameters.AddWithValue("@Phone", newPhone);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Contact updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAllContacts(); // Refresh DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating contact: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DeleteContact(int contactID)
        {
            DialogResult confirmDelete = MessageBox.Show("Are you sure you want to delete this contact?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirmDelete == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(dbConn))
                    {
                        conn.Open();
                        string query = "DELETE FROM Contacts WHERE ID = @ID";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@ID", contactID);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Contact deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAllContacts(); // Refresh list after deletion
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting contact: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            ExportToExcel();
        }

        private void lblDgv_Click(object sender, EventArgs e)
        {

        }
    }
}
