SELECT * FROM Contacts;

